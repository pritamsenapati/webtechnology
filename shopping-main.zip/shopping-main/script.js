const products = [
  {
    id: 1,
    name: 'Heritage Camera',
    price: 79.99,
    description: 'A minimalist camera with premium finish and crisp portraits.',
    img: 'https://images.unsplash.com/photo-1519183071298-a2962be54a35?q=80&w=900&auto=format&fit=crop',
  },
  {
    id: 2,
    name: 'Luxury Leather Wallet',
    price: 29.5,
    description: 'Soft, durable leather finished with sleek craftsmanship.',
    img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=900&auto=format&fit=crop',
  },
  {
    id: 3,
    name: 'Portable Bluetooth Speaker',
    price: 49.99,
    description: 'Compact audio with rich bass and wireless ease.',
    img: 'https://images.unsplash.com/photo-1580894894515-5cbf3c8f8f6a?q=80&w=900&auto=format&fit=crop',
  },
  {
    id: 4,
    name: 'Modern Sneakers',
    price: 89.0,
    description: 'Comfortable everyday sneakers designed for all-day style.',
    img: 'https://images.unsplash.com/photo-1618354695851-97f1a6f6c3c1?q=80&w=900&auto=format&fit=crop',
  },
  {
    id: 5,
    name: 'Elegant Watch',
    price: 119.0,
    description: 'A refined statement timepiece with a polished stainless finish.',
    img: 'https://images.unsplash.com/photo-1519741491183-090f6f9dff4a?q=80&w=900&auto=format&fit=crop',
  },
  {
    id: 6,
    name: 'Designer Backpack',
    price: 69.0,
    description: 'Functional storage with a premium silhouette.',
    img: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?q=80&w=900&auto=format&fit=crop',
  },
];

const $ = selector => document.querySelector(selector);
const productsGrid = $('#productsGrid');
const cartEl = $('#cart');
const cartItemsEl = $('#cartItems');
const cartCountEl = $('#cartCount');
const cartTotalEl = $('#cartTotal');
const cartToggle = $('#cartToggle');
const checkoutBtn = $('#checkoutBtn');
const buyNowBtn = $('#buyNowBtn');
const loginToggle = $('#loginToggle');
const loginModal = $('#loginModal');
const paymentModal = $('#paymentModal');
const confirmationModal = $('#confirmationModal');
const modalBackdrop = $('#modalBackdrop');
const loginClose = $('#loginClose');
const paymentClose = $('#paymentClose');
const confirmationClose = $('#confirmationClose');
const confirmationDone = $('#confirmationDone');
const loginForm = $('#loginForm');
const paymentForm = $('#paymentForm');
const searchInput = $('#searchInput');
const cardDetails = $('#cardDetails');
const loginButton = $('#loginToggle');
const confirmationTotal = $('#confirmationTotal');

let cart = JSON.parse(localStorage.getItem('cart') || '{}');
let searchQuery = '';
let isLoggedIn = JSON.parse(localStorage.getItem('isLoggedIn') || 'false');
let userEmail = localStorage.getItem('userEmail') || '';

function format(amount) {
  return amount.toFixed(2);
}

function getFilteredProducts() {
  const query = searchQuery.trim().toLowerCase();
  if (!query) return products;
  return products.filter(product =>
    product.name.toLowerCase().includes(query) ||
    product.description.toLowerCase().includes(query)
  );
}

function renderProducts() {
  const visibleItems = getFilteredProducts();
  productsGrid.innerHTML = '';

  if (!visibleItems.length) {
    productsGrid.innerHTML = '<div class="empty">No products matched your search.</div>';
    return;
  }

  visibleItems.forEach(product => {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${product.img}" alt="${product.name}">
      <div class="product-card-content">
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="product-meta">
          <div class="price">$${format(product.price)}</div>
          <button class="btn btn-primary" data-id="${product.id}">Add to cart</button>
        </div>
      </div>`;
    productsGrid.appendChild(card);
  });
}

function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function updateLoginState() {
  if (isLoggedIn) {
    loginButton.textContent = `Signed in: ${userEmail}`;
    loginButton.classList.add('logged-in');
  } else {
    loginButton.textContent = 'Sign in';
    loginButton.classList.remove('logged-in');
  }
}

function openModal(modal) {
  modalBackdrop.hidden = false;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}

function closeModal(modal) {
  modalBackdrop.hidden = true;
  modal.hidden = true;
  document.body.style.overflow = '';
}

function addToCart(id) {
  const key = id.toString();
  if (!cart[key]) {
    const product = products.find(item => item.id === id);
    cart[key] = { ...product, qty: 0 };
  }
  cart[key].qty += 1;
  saveCart();
  renderCart();
}

function updateQuantity(id, quantity) {
  const key = id.toString();
  if (!cart[key]) return;
  if (quantity <= 0) {
    delete cart[key];
  } else {
    cart[key].qty = quantity;
  }
  saveCart();
  renderCart();
}

function renderCart() {
  const items = Object.values(cart);
  cartItemsEl.innerHTML = '';

  if (!items.length) {
    cartItemsEl.innerHTML = '<div class="empty">Your cart is empty.</div>';
    cartCountEl.textContent = '0';
    cartTotalEl.textContent = '0.00';
    return;
  }

  let total = 0;
  let count = 0;

  items.forEach(item => {
    total += item.price * item.qty;
    count += item.qty;

    const row = document.createElement('div');
    row.className = 'cart-item';
    row.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <div class="item-info">
        <strong>${item.name}</strong>
        <span class="item-subtitle">$${format(item.price)} each</span>
      </div>
      <div>
        <div class="qty-controls">
          <button class="qty-button" data-action="dec" data-id="${item.id}">−</button>
          <span class="qty-value">${item.qty}</span>
          <button class="qty-button" data-action="inc" data-id="${item.id}">+</button>
        </div>
        <button class="remove-button" data-action="rem" data-id="${item.id}">Remove</button>
      </div>`;
    cartItemsEl.appendChild(row);
  });

  cartCountEl.textContent = count;
  cartTotalEl.textContent = format(total);
}

function loginUser(email) {
  isLoggedIn = true;
  userEmail = email;
  localStorage.setItem('isLoggedIn', JSON.stringify(true));
  localStorage.setItem('userEmail', email);
  updateLoginState();
}

function performCheckout() {
  const items = Object.values(cart);
  if (!items.length) {
    alert('Your cart is empty. Add something great before checkout.');
    return;
  }

  if (!isLoggedIn) {
    openModal(loginModal);
    return;
  }

  openModal(paymentModal);
}

function completePayment() {
  const total = Number(cartTotalEl.textContent);
  confirmationTotal.textContent = format(total);
  closeModal(paymentModal);
  openModal(confirmationModal);
  cart = {};
  saveCart();
  renderCart();
}

function showCardFields(method) {
  cardDetails.style.display = method === 'card' ? 'grid' : 'none';
}

searchInput?.addEventListener('input', event => {
  searchQuery = event.target.value;
  renderProducts();
});

productsGrid?.addEventListener('click', event => {
  const btn = event.target.closest('button[data-id]');
  if (!btn) return;
  const id = Number(btn.dataset.id);
  if (id) addToCart(id);
});

cartItemsEl?.addEventListener('click', event => {
  const btn = event.target.closest('button[data-action]');
  if (!btn) return;

  const action = btn.dataset.action;
  const id = Number(btn.dataset.id);
  const current = cart[id]?.qty || 0;

  if (action === 'inc') updateQuantity(id, current + 1);
  if (action === 'dec') updateQuantity(id, current - 1);
  if (action === 'rem') updateQuantity(id, 0);
});

cartToggle?.addEventListener('click', () => {
  cartEl.classList.toggle('open');
});

loginToggle?.addEventListener('click', () => {
  openModal(loginModal);
});

loginForm?.addEventListener('submit', event => {
  event.preventDefault();
  const emailField = $('#userEmail');
  const passwordField = $('#userPassword');
  if (!emailField.value || !passwordField.value) return;
  loginUser(emailField.value.trim());
  closeModal(loginModal);
});

checkoutBtn?.addEventListener('click', performCheckout);

buyNowBtn?.addEventListener('click', performCheckout);

paymentClose?.addEventListener('click', () => closeModal(paymentModal));
loginClose?.addEventListener('click', () => closeModal(loginModal));
confirmationClose?.addEventListener('click', () => closeModal(confirmationModal));
confirmationDone?.addEventListener('click', () => closeModal(confirmationModal));
modalBackdrop?.addEventListener('click', () => {
  closeModal(loginModal);
  closeModal(paymentModal);
  closeModal(confirmationModal);
});

paymentForm?.addEventListener('change', event => {
  const target = event.target;
  if (target.name === 'paymentMethod') {
    showCardFields(target.value);
  }
});

paymentForm?.addEventListener('submit', event => {
  event.preventDefault();
  completePayment();
});

function init() {
  updateLoginState();
  renderProducts();
  renderCart();
  showCardFields('card');
}

init();
