const form = document.getElementById("employeeForm");
const message = document.getElementById("message");
const tableBody = document.getElementById("employeeTableBody");

const employeeId = document.getElementById("employeeId");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const departmentInput = document.getElementById("department");
const phoneInput = document.getElementById("phone");
const salaryInput = document.getElementById("salary");

const saveButton = document.getElementById("saveButton");
const cancelButton = document.getElementById("cancelButton");


// Load employees when page opens
loadEmployees();


// ===============================
// LOAD EMPLOYEES
// ===============================

async function loadEmployees() {

    try {

        const response = await fetch("/employees");

        const employees = await response.json();

        tableBody.innerHTML = "";

        employees.forEach(employee => {

            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${employee.id}</td>
                <td>${employee.name}</td>
                <td>${employee.email}</td>
                <td>${employee.department}</td>
                <td>${employee.phone}</td>
                <td>₹${employee.salary}</td>

                <td>
                    <button
                        class="edit-btn"
                        onclick="editEmployee(${employee.id})">
                        Edit
                    </button>

                    <button
                        class="delete-btn"
                        onclick="deleteEmployee(${employee.id})">
                        Delete
                    </button>
                </td>
            `;

            tableBody.appendChild(row);

        });

    } catch (error) {

        console.log(error);

        message.textContent = "Unable to load employee details.";

    }
}


// ===============================
// SAVE / UPDATE EMPLOYEE
// ===============================

form.addEventListener("submit", async function (event) {

    event.preventDefault();

    const id = employeeId.value;

    const employee = {

        name: nameInput.value,
        email: emailInput.value,
        department: departmentInput.value,
        phone: phoneInput.value,
        salary: salaryInput.value

    };


    try {

        let response;

        // UPDATE
        if (id) {

            response = await fetch(`/employees/${id}`, {

                method: "PUT",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(employee)

            });

        }

        // INSERT
        else {

            response = await fetch("/employees", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(employee)

            });

        }


        const result = await response.json();

        if (response.ok) {

            message.textContent = result.message;

            clearForm();

            loadEmployees();

        } else {

            message.textContent = result.message;

        }

    } catch (error) {

        console.log(error);

        message.textContent = "Server error. Please try again.";

    }

});


// ===============================
// EDIT EMPLOYEE
// ===============================

async function editEmployee(id) {

    try {

        const response = await fetch("/employees");

        const employees = await response.json();

        const employee = employees.find(emp => emp.id === id);

        if (!employee) {
            return;
        }

        employeeId.value = employee.id;

        nameInput.value = employee.name;

        emailInput.value = employee.email;

        departmentInput.value = employee.department;

        phoneInput.value = employee.phone;

        salaryInput.value = employee.salary;


        saveButton.textContent = "Update Employee";

        message.textContent = "Editing employee #" + employee.id;

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } catch (error) {

        console.log(error);

    }
}


// ===============================
// DELETE EMPLOYEE
// ===============================

async function deleteEmployee(id) {

    const confirmDelete = confirm(
        "Are you sure you want to delete this employee?"
    );

    if (!confirmDelete) {
        return;
    }


    try {

        const response = await fetch(`/employees/${id}`, {

            method: "DELETE"

        });

        const result = await response.json();

        if (response.ok) {

            message.textContent = result.message;

            loadEmployees();

        } else {

            message.textContent = result.message;

        }

    } catch (error) {

        console.log(error);

        message.textContent = "Server error. Please try again.";

    }
}


// ===============================
// CLEAR FORM
// ===============================

function clearForm() {

    form.reset();

    employeeId.value = "";

    saveButton.textContent = "Save Employee";

}


// ===============================
// CANCEL EDIT
// ===============================

cancelButton.addEventListener("click", function () {

    clearForm();

    message.textContent = "";

});