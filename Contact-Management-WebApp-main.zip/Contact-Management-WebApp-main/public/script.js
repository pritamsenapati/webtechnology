// Get HTML elements

const contactForm = document.getElementById("contactForm");
const contactList = document.getElementById("contactList");

const nameInput = document.getElementById("name");
const phoneInput = document.getElementById("phone");
const emailInput = document.getElementById("email");
const addressInput = document.getElementById("address");

const contactIdInput = document.getElementById("contactId");

const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");


// Get contacts from LocalStorage

let contacts = JSON.parse(localStorage.getItem("contacts")) || [];


// Display contacts when page loads

displayContacts();


// Add / Update Contact

contactForm.addEventListener("submit", function (event) {

    event.preventDefault();

    const name = nameInput.value.trim();
    const phone = phoneInput.value.trim();
    const email = emailInput.value.trim();
    const address = addressInput.value.trim();

    // Validation

    if (name === "" || phone === "") {
        alert("Name and phone number are required.");
        return;
    }


    // Check if editing

    const contactId = contactIdInput.value;

    if (contactId === "") {

        // CREATE

        const newContact = {
            id: Date.now(),
            name: name,
            phone: phone,
            email: email,
            address: address
        };

        contacts.push(newContact);

        alert("Contact added successfully.");

    } else {

        // UPDATE

        contacts = contacts.map(function (contact) {

            if (contact.id == contactId) {

                return {
                    id: contact.id,
                    name: name,
                    phone: phone,
                    email: email,
                    address: address
                };

            }

            return contact;

        });

        alert("Contact updated successfully.");
    }


    // Save contacts

    saveContacts();

    // Display updated contacts

    displayContacts();

    // Reset form

    resetForm();

});


// Display Contacts

function displayContacts(contactArray = contacts) {

    contactList.innerHTML = "";

    if (contactArray.length === 0) {

        contactList.innerHTML = `
            <div class="empty-message">
                <h3>No contacts found</h3>
                <p>Add a contact to get started.</p>
            </div>
        `;

        return;
    }


    contactArray.forEach(function (contact) {

        const card = document.createElement("div");

        card.className = "contact-card";

        card.innerHTML = `

            <div class="contact-info">

                <h3>${contact.name}</h3>

                <p>
                    <strong>Phone:</strong>
                    ${contact.phone}
                </p>

                <p>
                    <strong>Email:</strong>
                    ${contact.email || "Not provided"}
                </p>

                <p>
                    <strong>Address:</strong>
                    ${contact.address || "Not provided"}
                </p>

            </div>

            <div class="contact-actions">

                <button
                    class="edit-btn"
                    onclick="editContact(${contact.id})"
                >
                    Edit
                </button>

                <button
                    class="delete-btn"
                    onclick="deleteContact(${contact.id})"
                >
                    Delete
                </button>

            </div>

        `;

        contactList.appendChild(card);

    });
}


// Edit Contact

function editContact(id) {

    const contact = contacts.find(function (contact) {

        return contact.id === id;

    });


    if (!contact) {
        return;
    }


    // Fill form with contact data

    nameInput.value = contact.name;
    phoneInput.value = contact.phone;
    emailInput.value = contact.email;
    addressInput.value = contact.address;

    contactIdInput.value = contact.id;


    // Change button

    submitBtn.textContent = "Update Contact";

    cancelBtn.style.display = "inline-block";


    // Scroll to form

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// Delete Contact

function deleteContact(id) {

    const confirmation = confirm(
        "Are you sure you want to delete this contact?"
    );


    if (!confirmation) {
        return;
    }


    contacts = contacts.filter(function (contact) {

        return contact.id !== id;

    });


    saveContacts();

    displayContacts();

    alert("Contact deleted successfully.");
}


// Search Contacts

function searchContacts() {

    const searchText =
        document.getElementById("searchInput")
        .value
        .toLowerCase();


    const filteredContacts = contacts.filter(function (contact) {

        return (
            contact.name.toLowerCase().includes(searchText) ||
            contact.phone.includes(searchText) ||
            contact.email.toLowerCase().includes(searchText)
        );

    });


    displayContacts(filteredContacts);
}


// Cancel Edit

function cancelEdit() {

    resetForm();

}


// Reset Form

function resetForm() {

    contactForm.reset();

    contactIdInput.value = "";

    submitBtn.textContent = "Add Contact";

    cancelBtn.style.display = "none";

}


// Save contacts to LocalStorage

function saveContacts() {

    localStorage.setItem(
        "contacts",
        JSON.stringify(contacts)
    );

}