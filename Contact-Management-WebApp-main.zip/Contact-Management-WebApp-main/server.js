const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Database initialization
const db = new sqlite3.Database('./contacts.db', (err) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});

// Initialize database table
function initializeDatabase() {
  db.run(`
    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL,
      address TEXT,
      city TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `, (err) => {
    if (err) {
      console.error('Table creation error:', err.message);
    } else {
      console.log('Contacts table ready');
    }
  });
}

// =====================
// API ENDPOINTS
// =====================

// GET all contacts
app.get('/api/contacts', (req, res) => {
  const query = 'SELECT * FROM contacts ORDER BY created_at DESC';
  
  db.all(query, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

// GET single contact by ID
app.get('/api/contacts/:id', (req, res) => {

  const { id } = req.params;
  
  const query = 'SELECT * FROM contacts WHERE id = ?';
  
  db.get(query, [id], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!row) {
      return res.status(404).json({ error: 'Contact not found' });
    }
    res.json(row);
  });
});

// POST - Add new contact
app.post('/api/contacts', (req, res) => {
  const { name, email, phone, address, city } = req.body;

  // Validation
  if (!name || !email || !phone) {
    return res.status(400).json({ 
      error: 'Name, email, and phone are required' 
    });
  }

  const query = `
    INSERT INTO contacts (name, email, phone, address, city)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.run(query, [name, email, phone, address, city], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(400).json({ error: 'Email already exists' });
      }
      return res.status(500).json({ error: err.message });
    }
    
    res.status(201).json({ 
      id: this.lastID,
      name,
      email,
      phone,
      address,
      city,
      message: 'Contact added successfully'
    });
  });
});

// PUT - Update contact
app.put('/api/contacts/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, phone, address, city } = req.body;

  if (!name || !email || !phone) {
    return res.status(400).json({ 
      error: 'Name, email, and phone are required' 
    });
  }

  const query = `
    UPDATE contacts 
    SET name = ?, email = ?, phone = ?, address = ?, city = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `;

  db.run(query, [name, email, phone, address, city, id], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(400).json({ error: 'Email already exists' });
      }
      return res.status(500).json({ error: err.message });
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json({ 
      message: 'Contact updated successfully',
      id,
      name,
      email,
      phone,
      address,
      city
    });
  });
});

// DELETE - Remove contact
app.delete('/api/contacts/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM contacts WHERE id = ?';

  db.run(query, [id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json({ message: 'Contact deleted successfully', id });
  });
});

// Search contacts
app.get('/api/search', (req, res) => {
  const { query } = req.query;

  if (!query) {
    return res.status(400).json({ error: 'Search query is required' });
  }

  const searchQuery = `
    SELECT * FROM contacts 
    WHERE name LIKE ? OR email LIKE ? OR phone LIKE ?
    ORDER BY created_at DESC
  `;

  const searchTerm = `%${query}%`;
  db.all(searchQuery, [searchTerm, searchTerm, searchTerm], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

// Server startup
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
  console.log('📱 Contact Management API ready');
});

// Graceful shutdown
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Database connection closed');
    process.exit(0);
  });
});

