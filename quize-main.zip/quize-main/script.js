const quizSets = {
    movie: {
        title: 'Movie Quiz',
        questions: [
            { question: 'Who directed Inception?', options: ['Christopher Nolan', 'Steven Spielberg', 'James Cameron', 'Ridley Scott'], answer: 'Christopher Nolan' },
            { question: 'Which movie features the line “May the Force be with you”?', options: ['Star Wars', 'Avatar', 'Titanic', 'The Matrix'], answer: 'Star Wars' },
            { question: 'What is the name of the fictional African nation in Black Panther?', options: ['Wakanda', 'Zamunda', 'Naboo', 'Genovia'], answer: 'Wakanda' },
            { question: 'Who played Jack Dawson in Titanic?', options: ['Leonardo DiCaprio', 'Brad Pitt', 'Tom Cruise', 'Johnny Depp'], answer: 'Leonardo DiCaprio' },
            { question: 'Which movie won the Oscar for Best Picture in 2020?', options: ['1917', 'Parasite', 'Joker', 'Once Upon a Time in Hollywood'], answer: 'Parasite' },
            { question: 'Who played Wolverine in the X-Men films?', options: ['Hugh Jackman', 'Ryan Reynolds', 'Chris Evans', 'Liam Neeson'], answer: 'Hugh Jackman' },
            { question: 'Which film features the character Harry Potter?', options: ['The Hobbit', 'Harry Potter and the Sorcerer\'s Stone', 'The Lord of the Rings', 'Percy Jackson'], answer: 'Harry Potter and the Sorcerer\'s Stone' },
            { question: 'In which movie would you find the character Jack Sparrow?', options: ['Pirates of the Caribbean', 'The Lion King', 'Gladiator', 'The Avengers'], answer: 'Pirates of the Caribbean' },
            { question: 'Which movie is about a young girl named Elsa?', options: ['Frozen', 'Moana', 'Tangled', 'Brave'], answer: 'Frozen' },
            { question: 'Who directed the movie Interstellar?', options: ['Christopher Nolan', 'Denis Villeneuve', 'Ridley Scott', 'James Cameron'], answer: 'Christopher Nolan' },
            { question: 'What is the name of the fictional island in Jurassic Park?', options: ['Isla Nublar', 'Alderaan', 'Pandora', 'Narnia'], answer: 'Isla Nublar' },
            { question: 'Which actor played Tony Stark in the Marvel films?', options: ['Chris Hemsworth', 'Robert Downey Jr.', 'Mark Ruffalo', 'Tom Holland'], answer: 'Robert Downey Jr.' },
            { question: 'Which movie features the character Simba?', options: ['The Lion King', 'Aladdin', 'Mulan', 'Shrek'], answer: 'The Lion King' },
            { question: 'Who directed the film Titanic?', options: ['Steven Spielberg', 'James Cameron', 'Martin Scorsese', 'David Fincher'], answer: 'James Cameron' },
            { question: 'Which movie is about a dystopian future and a boy named Neo?', options: ['The Matrix', 'Blade Runner', 'Minority Report', 'Inception'], answer: 'The Matrix' },
            { question: 'What is the name of the wizard in The Hobbit?', options: ['Gandalf', 'Dumbledore', 'Saruman', 'Merlin'], answer: 'Gandalf' },
            { question: 'Which movie features the giant blue creatures called Na’vi?', options: ['Avatar', 'Dune', 'Alien', 'Gravity'], answer: 'Avatar' },
            { question: 'Who played the character Hermione Granger?', options: ['Emma Watson', 'Keira Knightley', 'Natalie Portman', 'Lily Collins'], answer: 'Emma Watson' },
            { question: 'In which movie does a boy named Woody appear?', options: ['Toy Story', 'Cars', 'Ratatouille', 'Finding Nemo'], answer: 'Toy Story' },
            { question: 'Which movie is about the journey of a young girl named Arwen?', options: ['The Lord of the Rings', 'The Hunger Games', 'Twilight', 'Beauty and the Beast'], answer: 'The Lord of the Rings' }
        ]
    },
    general: {
        title: 'General Quiz',
        questions: [
            { question: 'What is the capital of France?', options: ['Berlin', 'Madrid', 'Paris', 'Rome'], answer: 'Paris' },
            { question: 'Which planet is known as the Red Planet?', options: ['Venus', 'Mars', 'Mercury', 'Jupiter'], answer: 'Mars' },
            { question: 'How many continents are there?', options: ['5', '6', '7', '8'], answer: '7' },
            { question: 'What is 2 + 2?', options: ['3', '4', '5', '6'], answer: '4' },
            { question: 'Which language runs in a web browser?', options: ['Python', 'Java', 'C', 'JavaScript'], answer: 'JavaScript' },
            { question: 'What does HTML stand for?', options: ['Hyper Text Markup Language', 'High Transfer Machine Language', 'Hyperlinks and Text Markup Language', 'Home Tool Markup Language'], answer: 'Hyper Text Markup Language' },
            { question: 'Which animal is known as the King of the Jungle?', options: ['Elephant', 'Lion', 'Tiger', 'Wolf'], answer: 'Lion' },
            { question: 'How many days are there in a leap year?', options: ['364', '365', '366', '367'], answer: '366' },
            { question: 'What is the largest ocean on Earth?', options: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'], answer: 'Pacific Ocean' },
            { question: 'Who wrote Romeo and Juliet?', options: ['Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain'], answer: 'William Shakespeare' },
            { question: 'What is the boiling point of water at sea level?', options: ['90°C', '100°C', '110°C', '120°C'], answer: '100°C' },
            { question: 'Which country is famous for the pyramids?', options: ['Mexico', 'India', 'Egypt', 'Greece'], answer: 'Egypt' },
            { question: 'What is the chemical symbol for gold?', options: ['Go', 'Gd', 'Au', 'Ag'], answer: 'Au' },
            { question: 'Which instrument has 88 keys?', options: ['Guitar', 'Violin', 'Piano', 'Drums'], answer: 'Piano' },
            { question: 'What is the square root of 64?', options: ['6', '7', '8', '9'], answer: '8' },
            { question: 'Which month has 28 days?', options: ['February', 'April', 'June', 'November'], answer: 'February' },
            { question: 'What is the fastest land animal?', options: ['Cheetah', 'Horse', 'Rabbit', 'Lion'], answer: 'Cheetah' },
            { question: 'Which element has the chemical symbol O?', options: ['Gold', 'Oxygen', 'Silver', 'Hydrogen'], answer: 'Oxygen' },
            { question: 'Which part of the human body pumps blood?', options: ['Lungs', 'Heart', 'Kidneys', 'Brain'], answer: 'Heart' },
            { question: 'What is the currency of Japan?', options: ['Yuan', 'Won', 'Yen', 'Rupee'], answer: 'Yen' }
        ]
    },
    history: {
        title: 'History Quiz',
        questions: [
            { question: 'Who was the first President of the United States?', options: ['Thomas Jefferson', 'George Washington', 'Abraham Lincoln', 'John Adams'], answer: 'George Washington' },
            { question: 'In which year did World War II end?', options: ['1943', '1945', '1950', '1939'], answer: '1945' },
            { question: 'Which ancient civilization built Machu Picchu?', options: ['Romans', 'Maya', 'Inca', 'Greeks'], answer: 'Inca' },
            { question: 'Who discovered America in 1492?', options: ['Christopher Columbus', 'Vasco da Gama', 'Ferdinand Magellan', 'Marco Polo'], answer: 'Christopher Columbus' },
            { question: 'The Great Wall of China was built mainly to protect against which group?', options: ['Vikings', 'Mongols', 'Ottomans', 'Persians'], answer: 'Mongols' },
            { question: 'Which empire was ruled by Julius Caesar?', options: ['Roman Empire', 'Ottoman Empire', 'Persian Empire', 'Mongol Empire'], answer: 'Roman Empire' },
            { question: 'Who was the first emperor of China?', options: ['Sun Yat-sen', 'Qin Shi Huang', 'Mao Zedong', 'Kublai Khan'], answer: 'Qin Shi Huang' },
            { question: 'In which year did the Berlin Wall fall?', options: ['1987', '1989', '1991', '1993'], answer: '1989' },
            { question: 'Which civilization built the city of Petra?', options: ['Nabataeans', 'Romans', 'Greeks', 'Persians'], answer: 'Nabataeans' },
            { question: 'Who wrote the Declaration of Independence?', options: ['Thomas Jefferson', 'George Washington', 'Benjamin Franklin', 'John Adams'], answer: 'Thomas Jefferson' },
            { question: 'Which battle marked the end of Napoleon\'s rule?', options: ['Battle of Waterloo', 'Battle of Hastings', 'Battle of Gettysburg', 'Battle of Borodino'], answer: 'Battle of Waterloo' },
            { question: 'Which dynasty built the Taj Mahal?', options: ['Gupta', 'Mughal', 'Maurya', 'Chola'], answer: 'Mughal' },
            { question: 'Who was the famous queen of Egypt known as Cleopatra?', options: ['Ptolemaic ruler', 'Persian ruler', 'Mesopotamian ruler', 'Mongol ruler'], answer: 'Ptolemaic ruler' },
            { question: 'Which ancient civilization used hieroglyphics?', options: ['Egyptians', 'Romans', 'Greeks', 'Persians'], answer: 'Egyptians' },
            { question: 'Who was the leader of the Soviet Union during most of World War II?', options: ['Vladimir Lenin', 'Joseph Stalin', 'Nikita Khrushchev', 'Mikhail Gorbachev'], answer: 'Joseph Stalin' },
            { question: 'Which country was ruled by Queen Elizabeth I?', options: ['France', 'Spain', 'England', 'Portugal'], answer: 'England' },
            { question: 'The Roman Colosseum was built in which city?', options: ['Athens', 'Rome', 'Carthage', 'Alexandria'], answer: 'Rome' },
            { question: 'Which explorer sailed around the Cape of Good Hope?', options: ['Christopher Columbus', 'Vasco da Gama', 'Ferdinand Magellan', 'Marco Polo'], answer: 'Vasco da Gama' },
            { question: 'What is the ancient name of the city now known as Istanbul?', options: ['Byzantium', 'Carthage', 'Athens', 'Jerusalem'], answer: 'Byzantium' },
            { question: 'Which empire was defeated by the Mongols at the Battle of Ain Jalut?', options: ['Ottoman Empire', 'Abbasid Caliphate', 'Mamluk Sultanate', 'Byzantine Empire'], answer: 'Mamluk Sultanate' }
        ]
    },
    english: {
        title: 'English Quiz',
        questions: [
            { question: 'Which word is a synonym of “happy”?', options: ['Sad', 'Joyful', 'Angry', 'Tired'], answer: 'Joyful' },
            { question: 'What is the plural of “child”?', options: ['Childs', 'Childes', 'Children', 'Childrens'], answer: 'Children' },
            { question: 'Choose the correct sentence:', options: ['She don’t like tea.', 'She doesn’t like tea.', 'She not like tea.', 'She is not liking tea.'], answer: 'She doesn’t like tea.' },
            { question: 'What is the opposite of “difficult”?', options: ['Easy', 'Hard', 'Tough', 'Complex'], answer: 'Easy' },
            { question: 'Which word completes the sentence: “He is very ___.”', options: ['kindly', 'kind', 'kinder', 'kindness'], answer: 'kind' },
            { question: 'Which word means “quickly”?', options: ['Slowly', 'Fast', 'Softly', 'Gently'], answer: 'Fast' },
            { question: 'Choose the correct spelling:', options: ['Recieve', 'Receive', 'Receeve', 'Receve'], answer: 'Receive' },
            { question: 'What is the past tense of “go”?', options: ['Goed', 'Gone', 'Went', 'Going'], answer: 'Went' },
            { question: 'Which sentence is grammatically correct?', options: ['They is playing.', 'They are playing.', 'They am playing.', 'They be playing.'], answer: 'They are playing.' },
            { question: 'What is the opposite of “beautiful”?', options: ['Pretty', 'Ugly', 'Lovely', 'Bright'], answer: 'Ugly' },
            { question: 'Choose the correct article: “___ apple a day.”', options: ['A', 'An', 'The', 'No article'], answer: 'An' },
            { question: 'Which word is a noun?', options: ['Run', 'Happy', 'Book', 'Quickly'], answer: 'Book' },
            { question: 'What is the comparative form of “big”?', options: ['Biger', 'More big', 'Bigger', 'Biggest'], answer: 'Bigger' },
            { question: 'Which word means “to make something smaller”?', options: ['Expand', 'Reduce', 'Increase', 'Grow'], answer: 'Reduce' },
            { question: 'Choose the correct pronoun: “___ are going to school.”', options: ['He', 'She', 'They', 'It'], answer: 'They' },
            { question: 'What is the superlative form of “good”?', options: ['Gooder', 'Best', 'Better', 'More good'], answer: 'Best' },
            { question: 'Which word is the opposite of “always”?', options: ['Never', 'Often', 'Sometimes', 'Usually'], answer: 'Never' },
            { question: 'What is the plural of “mouse”?', options: ['Mouses', 'Mice', 'Mouses', 'Mices'], answer: 'Mice' },
            { question: 'Which sentence uses the correct punctuation?', options: ['Lets go home!', 'Let’s go home!', 'Lets go home.', 'Lets, go home!'], answer: 'Let’s go home!' },
            { question: 'What does “brave” mean?', options: ['Fearful', 'Cowardly', 'Courageous', 'Shy'], answer: 'Courageous' }
        ]
    },
    current: {
        title: 'Current Affairs Quiz',
        questions: [
            { question: 'Which country hosted the 2023 FIFA Women’s World Cup?', options: ['Australia', 'Japan', 'France', 'USA'], answer: 'Australia' },
            { question: 'Who became the Prime Minister of India in 2024?', options: ['Rahul Gandhi', 'Narendra Modi', 'Amit Shah', 'Manmohan Singh'], answer: 'Narendra Modi' },
            { question: 'Which company released ChatGPT?', options: ['Google', 'OpenAI', 'Meta', 'Microsoft'], answer: 'OpenAI' },
            { question: 'What is the currency of Japan?', options: ['Yuan', 'Won', 'Yen', 'Rupee'], answer: 'Yen' },
            { question: 'Which planet is known as the “Red Planet”?', options: ['Venus', 'Mars', 'Mercury', 'Jupiter'], answer: 'Mars' },
            { question: 'Which country won the 2022 FIFA World Cup?', options: ['Argentina', 'France', 'Brazil', 'Germany'], answer: 'Argentina' },
            { question: 'Who is the current Secretary-General of the United Nations?', options: ['Ban Ki-moon', 'António Guterres', 'Kofi Annan', 'Boutros Boutros-Ghali'], answer: 'António Guterres' },
            { question: 'What is the name of the social media platform owned by Meta?', options: ['Twitter', 'Instagram', 'TikTok', 'Snapchat'], answer: 'Instagram' },
            { question: 'Which company launched the iPhone 15?', options: ['Samsung', 'Apple', 'Google', 'OnePlus'], answer: 'Apple' },
            { question: 'Which country is famous for the city of Dubai?', options: ['Saudi Arabia', 'UAE', 'Qatar', 'Oman'], answer: 'UAE' },
            { question: 'What does AI stand for?', options: ['Artificial Intelligence', 'Advanced Input', 'Automated Interface', 'Automated Internet'], answer: 'Artificial Intelligence' },
            { question: 'Who is the author of the book “Atomic Habits”?', options: ['James Clear', 'Mark Manson', 'Ryan Holiday', 'Tony Robbins'], answer: 'James Clear' },
            { question: 'Which organization is responsible for the Olympics?', options: ['FIFA', 'IOC', 'NBA', 'ICC'], answer: 'IOC' },
            { question: 'Which of these is a renewable energy source?', options: ['Coal', 'Oil', 'Solar', 'Natural Gas'], answer: 'Solar' },
            { question: 'What is the capital of Australia?', options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'], answer: 'Canberra' },
            { question: 'Which country is known for the city of Tokyo?', options: ['China', 'Japan', 'South Korea', 'Thailand'], answer: 'Japan' },
            { question: 'Which technology company developed the Android operating system?', options: ['Apple', 'Google', 'Microsoft', 'Amazon'], answer: 'Google' },
            { question: 'Which sport uses the term “love” as a score?', options: ['Cricket', 'Tennis', 'Football', 'Badminton'], answer: 'Tennis' },
            { question: 'Which planet is the largest in our solar system?', options: ['Mars', 'Saturn', 'Jupiter', 'Neptune'], answer: 'Jupiter' },
            { question: 'What is the full form of NASA?', options: ['National Aeronautics and Space Administration', 'National Air and Space Agency', 'North American Space Association', 'National Aviation Society Association'], answer: 'National Aeronautics and Space Administration' }
        ]
    }
};

let quizQuestions = [];
let currentQuestion = 0;
let score = 0;
let activeCategory = '';
let countdownTimer = null;
let timeRemaining = 15 * 60;
let userAnswers = [];

const categoryScreen = document.getElementById('category-screen');
const quizBox = document.getElementById('quiz-box');
const resultEl = document.getElementById('result');
const questionEl = document.getElementById('question');
const optionsEl = document.getElementById('options');
const progressEl = document.getElementById('progress');
const sectionTitleEl = document.getElementById('section-title');
const timerEl = document.getElementById('timer');
const backBtn = document.getElementById('back-btn');

function clearTimer() {
    if (countdownTimer) {
        clearInterval(countdownTimer);
        countdownTimer = null;
    }
}

function updateTimer() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    timerEl.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function startTimer() {
    clearTimer();
    timeRemaining = 15 * 60;
    updateTimer();
    countdownTimer = setInterval(() => {
        timeRemaining -= 1;
        updateTimer();
        if (timeRemaining <= 0) {
            clearTimer();
            showResult();
        }
    }, 1000);
}

function showCategoryScreen() {
    clearTimer();
    categoryScreen.classList.remove('hidden');
    quizBox.classList.add('hidden');
    resultEl.classList.add('hidden');
}

function shuffleQuestions(questions) {
    const array = [...questions];
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function startQuiz(category) {
    activeCategory = category;
    currentQuestion = 0;
    score = 0;
    userAnswers = [];
    quizQuestions = shuffleQuestions(quizSets[category].questions).slice(0, 20);
    categoryScreen.classList.add('hidden');
    quizBox.classList.remove('hidden');
    resultEl.classList.add('hidden');
    startTimer();
    showQuestion();
}

function showQuestion() {
    const q = quizQuestions[currentQuestion];
    sectionTitleEl.textContent = quizSets[activeCategory].title;
    questionEl.textContent = q.question;
    progressEl.textContent = `Question ${currentQuestion + 1} of ${quizQuestions.length}`;
    optionsEl.innerHTML = '';

    q.options.forEach((option) => {
        const button = document.createElement('button');
        button.className = 'option-btn';
        button.textContent = option;
        button.onclick = () => {
            userAnswers[currentQuestion] = {
                selected: option,
                correct: q.answer,
                isCorrect: option === q.answer
            };

            if (option === q.answer) {
                score++;
            }

            currentQuestion++;

            if (currentQuestion < quizQuestions.length) {
                showQuestion();
            } else {
                showResult();
            }
        };
        optionsEl.appendChild(button);
    });
}

function showResult() {
    clearTimer();

    if (userAnswers[currentQuestion] === undefined) {
        userAnswers[currentQuestion] = {
            selected: 'Not answered',
            correct: quizQuestions[currentQuestion]?.answer || '',
            isCorrect: false
        };
    }

    quizBox.classList.add('hidden');
    resultEl.classList.remove('hidden');

    const answerSheetHTML = quizQuestions.map((q, index) => {
        const answerData = userAnswers[index] || {
            selected: 'Not answered',
            correct: q.answer,
            isCorrect: false
        };

        return `
            <div class="answer-item ${answerData.isCorrect ? 'correct' : 'incorrect'}">
                <p><strong>${index + 1}. ${q.question}</strong></p>
                <p>Your answer: <span class="answer-value">${answerData.selected}</span></p>
                <p>Correct answer: <span class="answer-value">${q.answer}</span></p>
            </div>
        `;
    }).join('');

    resultEl.innerHTML = `
        <h2>Quiz Finished!</h2>
        <p>Your score is <strong>${score}</strong> out of <strong>${quizQuestions.length}</strong>.</p>
        <div class="answer-sheet">
            ${answerSheetHTML}
        </div>
        <button id="restart-btn" class="primary-btn">Try Another Section</button>
    `;
    document.getElementById('restart-btn').onclick = showCategoryScreen;
}

backBtn.addEventListener('click', showCategoryScreen);

document.querySelectorAll('.category-btn').forEach((button) => {
    button.addEventListener('click', () => startQuiz(button.dataset.category));
});

showCategoryScreen();